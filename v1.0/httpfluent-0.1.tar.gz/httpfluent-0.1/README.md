## Features
You can use http requests and threading same time with additional features 
## Installation

install threadfluent using `pip`:

```bash
$ pip install threadfluent
```