## Features
You can use http requests and threading same time with additional features 
## Installation

You can install httpfluent using `pip`:

```bash
$ pip install httpfluent
```