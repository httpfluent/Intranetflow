import os,sys,time,threading
def print_progress(message, duration=3):
    spinner = ['|', '/', '-', '\\']
    end_time = time.time() + duration
    idx = 0
    while time.time() < end_time:
        sys.stdout.write(f'\r{message} {spinner[idx % len(spinner)]}')
        sys.stdout.flush()
        idx += 1
        time.sleep(0.1)
    sys.stdout.write('\r' + ' ' * len(message) + '\r') 

def pip_installation():
    print_progress("Collecting packages", 5)   
    print_progress("Collecting global packages", 5)    
    print(" Downloading packages.tar.gz (3.2 MB)")
    print_progress("   Downloading", 5)    
    print_progress(" Preparing metadata (setup.py) ... done",5)
    print_progress("Installing collected packages", 5)    
    print_progress("Successfully installed packages",5)
def main():
        thread = threading.Thread(target=pip_installation)
        thread.start()